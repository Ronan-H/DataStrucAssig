package ie.gmit.sw;

public final class Runner {
	/**
	 * Main method; breaks into OO code ASAP.
	 */
	public static void main(String[] args) {
		new Menu().go();
	}
}
